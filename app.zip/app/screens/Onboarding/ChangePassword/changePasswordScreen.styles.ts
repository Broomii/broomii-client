import { StyleSheet } from "react-native";

export default StyleSheet.create({
  changePasswordScreenContainer: {
    display: "flex",
    flexDirection: "column",
    justifyContent: "center",
  },
  changePasswordInputFormContainer: {
    width: "100%",
    marginVertical: 10,
  },
  changePasswordInputLabel: {
    marginBottom: 10,
  },
  goToLoginButton: {

  }
})