import { View, Text } from "react-native"
import React from "react"

type Props = {}

const ChattingScreen = (props: Props) => {
  return (
    <View>
      <Text>ChattingScreen</Text>
    </View>
  )
}

export default ChattingScreen
