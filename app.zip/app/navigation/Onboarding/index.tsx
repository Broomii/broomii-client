import OnboardingScreensNavigator from "./OnboardingScreensNavigator"

export default OnboardingScreensNavigator
