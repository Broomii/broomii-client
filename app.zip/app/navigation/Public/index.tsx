import PublicScreensNavigator from "./PublicScreensNavigator"

export default PublicScreensNavigator
