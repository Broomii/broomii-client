import { View, Text } from "react-native"
import React from "react"

type Props = {}

const ChattingNavigator = (props: Props) => {
  return (
    <View>
      <Text>ChattingNavigator</Text>
    </View>
  )
}

export default ChattingNavigator
