export { default } from "./Settings.navigator"
