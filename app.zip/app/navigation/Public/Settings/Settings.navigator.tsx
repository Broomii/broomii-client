import { View, Text } from "react-native"
import React from "react"

type Props = {}

const SettingsNavigator = (props: Props) => {
  return (
    <View>
      <Text>SettingsNavigator</Text>
    </View>
  )
}

export default SettingsNavigator
