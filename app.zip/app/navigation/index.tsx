import AppNavigator from "./App.navigator"
import { Text } from "react-native"

const Navigation = () => {
  return <AppNavigator />
}

export default Navigation
