export { default } from "./colors"
