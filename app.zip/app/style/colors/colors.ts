export default {
  brand: "#798DFF",
  primary: "black",
  primaryInvert: "white",
  gray100: "#D9D9D9",
  gray300: "#D7D7D7",
  gray500: "#8D8D8D",
  error: "#FF597B",
}
