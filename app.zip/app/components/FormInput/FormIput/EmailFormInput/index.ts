import EmailFormInput from "./EmailFormInput"

export default EmailFormInput
