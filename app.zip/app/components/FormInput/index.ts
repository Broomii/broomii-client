import FormInput from "./FormIput"
import FormInputLabel from "./FormInputLabel"
import FormInputError from "./FormInputError"
import EmailFormInput from "./FormIput/EmailFormInput"

export { FormInput, FormInputLabel, FormInputError, EmailFormInput }
