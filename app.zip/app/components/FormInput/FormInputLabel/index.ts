import FormInputLabel from "./FormInputLabel"

export default FormInputLabel
