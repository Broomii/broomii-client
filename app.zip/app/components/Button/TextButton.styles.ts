import { StyleSheet } from "react-native"
import { Font } from "../../style/font"

export default StyleSheet.create({
  textButtonTitle: {
    fontFamily: Font.FontWeight.Light,
  },
})
